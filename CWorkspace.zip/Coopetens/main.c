/*
 * main.c
 *
 *  Created on: Sep 28, 2016
 *      Author: gordonwang
 */

#include <stdio.h>
#include <pthread.h>

#define NUM_PTHREADS 5

void* say_hello(void* args)
{
	printf("当前线程:%d ",args);
	//pthread_exit(NULL);
	return 0;
}

int fibonaci(int i)
{
   if(i == 0)
   {
      return 0;
   }
   if(i == 1)
   {
      return 1;
   }
   return fibonaci(i-1) + fibonaci(i-2);
}

int main(void){
	//pthread_t pthreads[NUM_PTHREADS];
	//int txt[NUM_PTHREADS];
	printf("\r\n");
	for(int i=0;i<100;i++){
		printf("%d\t%n",fibonaci(i));
	}
	/*
	for(int i=0;i<NUM_PTHREADS;i++){
		txt[i] = i;
		//创建线程
		int ret = pthread_create(&pthreads[i],NULL,say_hello,(void *)&(txt[i]));
		if(ret!=0){
			printf("出错了");
		}
	}
	*/
	//终止线程
	//pthread_exit(NULL);


}
